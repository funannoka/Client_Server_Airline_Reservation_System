/* TCPechod.c - main, TCPechod */
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#define QLEN 5 /* maximum connection queue length */
#define BUFSIZE 4096
extern int errno;
//sem_t sock_lock;

void reaper(int);
void *fileCopy(void *vargp);
int errexit(const char *format, ...);
int passiveTCP(const char *service, int qlen);
/*------------------------------------------------------------------------
 * main - Concurrent TCP server for ECHO service
 *------------------------------------------------------------------------
 */
int msock; /* master server socket */
int
main(int argc, char *argv[])
{
    char *service = "5500"; /* service name or port number */
    pthread_t tid;
    switch (argc) {
        case 1:
            break;
        case 2:
            service = argv[1];
            break;
        default:
            errexit("usage: TCPechod [port]\n");
    }
    msock = passiveTCP(service, QLEN);
    //printf("%d\n",msock);
    while(1){
        pthread_create(&tid, NULL, fileCopy, (void*)msock);
        pthread_join(tid, NULL);
        
    }
    pthread_exit(NULL);
}
/*------------------------------------------------------------------------
 * TCPechod - echo data until end of file
 *------------------------------------------------------------------------
 */
void *fileCopy(void *vargp)
{
    int fd = (int) vargp;
    struct sockaddr_in fsin; /* the address of a client */
    socklen_t alen; /* length of client's address */
    char fromclient[256];
    FILE *source;
  //  sem_init(&sock_lock,0,1);
    char buff[1001];
    char buffer[1001];
    char *token;
    int n,n1;
    int ssock; /* slave server socket */
    unsigned int secs;
    unsigned int retTime;
    alen = sizeof(fsin);
    printf("thread executing\n");
 //   sem_wait(&sock_lock);
    
    ssock = accept(fd, (struct sockaddr *)&fsin, &alen);
    if (ssock < 0) {
        if (errno == EINTR)
            errexit("accept: %s\n", strerror(errno));
    }
    bzero(fromclient,256);
    /*Reading value from the client*/
    
    n = read(ssock,fromclient,255);
    if (n < 0)
        errexit("ERROR reading from socket %s\n", strerror(errno));
    else
    {
        bzero(buff,1001);
        token = strtok(fromclient, " /");
        int i=0;
        while( token != NULL && i<1)
        {
            token = strtok(NULL, " /");
            i++;
        }
        printf("Request from client for file: %s\n",token);
        n=strlen(token);
        token[n] = '\0';
        if (token[strlen(token)-1] == '\n')
            token[strlen(token)-1] = '\0';
        if (token[strlen(token)-1] == '\r')
            token[strlen(token)-1] = '\0';

        if((source = fopen(token, "r"))==NULL){
            bzero(buff,1001);
            strcat(buff, "HTTP/1.1 404 Not Found\r\n");
            strcat(buff, "Connection: close\r\n");
            strcat(buff, "Content-length: 1500\r\n");
            strcat(buff, "Content-Type: text/html\r\n\n");
            strcat(buff,"<html><body><H1>404 File Not Found</H1></body></html>");
            n1=write(ssock,buff ,strlen(buff));
            if (n1 <= 0)
            {
                errexit("ERROR writing to socket\n");
            }
          //  (void) close(ssock);
        }
        else{
            bzero(buffer,1001);
            fread(buff,1001, 1,source);
            strcat(buffer, "HTTP/1.1 200 OK\n");
            strcat(buffer, "Connection: Close\n");
            strcat(buffer, "Content-length: 1500\n");
            strcat(buffer, "Content-Type: text/html\n\n");
            strcat(buffer,"<html><body><H1>");
            strcat(buffer,buff);
            strcat(buffer,"</H1></body></html>\n");
            n1=write(ssock, buffer,strlen(buffer));
            if (n1 <= 0)
            {
                errexit("ERROR writing to socket\n");
            }
         //   (void) close(ssock);
        }
     //   sem_post(&sock_lock);
        fclose(source);
    }
    
    (void) close(ssock);
    return(0);
}
